package com.example.demoredis;

import java.io.Serializable;

public class Employee implements Serializable {
}
